<?php

/**
 * Get the Plugin Default Options.
 *
 * @since 1.0.0
 *
 * @param null
 *
 * @return 
 *
 * @author     trakadev <trakadev@protonmail.com>
 *
 */

 // If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}